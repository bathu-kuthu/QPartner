import React, { useState, useEffect, useRef } from 'react';
import {
    View, Text, TouchableOpacity, StyleSheet, Alert,
    Linking, ActivityIndicator, BackHandler,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { colors, Fonts } from '@/constants/colors';
import { DriverService } from '@/services/driver.service';
import { useAuth } from '@/contexts/auth-context';
import { Ride } from '@/types';
import { useTranslation } from 'react-i18next';

export default function ActiveRideScreen() {
    const insets = useSafeAreaInsets();
    const { id } = useLocalSearchParams<{ id: string }>();
    const { driver, setDriverData } = useAuth();
    const { t } = useTranslation();
    const [ride, setRide] = useState<Ride | null>(null);
    const [loading, setLoading] = useState(true);
    const [updating, setUpdating] = useState(false);
    const channelRef = useRef<any>(null);

    const STATUS_STEPS = [
        { key: 'accepted', label: t('activeRide.steps.accepted'), icon: 'navigation', action: t('activeRide.actions.confirm_pickup'), nextStatus: 'picked_up' as const },
        { key: 'picked_up', label: t('activeRide.steps.picked_up'), icon: 'user-check', action: t('activeRide.actions.start_ride'), nextStatus: 'on_ride' as const },
        { key: 'on_ride', label: t('activeRide.steps.on_ride'), icon: 'truck', action: t('activeRide.actions.complete_ride'), nextStatus: 'completed' as const },
    ];

    useEffect(() => {
        loadRide();

        // Block hardware back button — driver must complete the ride
        const backHandler = BackHandler.addEventListener('hardwareBackPress', () => true);
        return () => backHandler.remove();
    }, [id]);

    useEffect(() => {
        if (!ride?.id) return;
        channelRef.current = DriverService.subscribeToRide(ride.id, (updated) => {
            setRide(updated);
        });
        return () => channelRef.current?.unsubscribe?.();
    }, [ride?.id]);

    const loadRide = async () => {
        if (!id) return;
        try {
            const active = await DriverService.getActiveRide(driver?.id ?? '');
            setRide(active);
        } finally {
            setLoading(false);
        }
    };

    const handleStatusUpdate = async () => {
        if (!ride) return;
        const step = STATUS_STEPS.find(s => s.key === ride.status);
        if (!step) return;

        if (step.nextStatus === 'completed') {
            Alert.alert(
                t('activeRide.completeRide'),
                t('activeRide.completeConfirm'),
                [
                    { text: t('common.cancel'), style: 'cancel' },
                    { text: t('common.complete'), style: 'default', onPress: () => doUpdate(step.nextStatus) },
                ]
            );
        } else {
            doUpdate(step.nextStatus);
        }
    };

    const doUpdate = async (newStatus: 'picked_up' | 'on_ride' | 'completed') => {
        if (!ride?.id || updating) return;
        setUpdating(true);
        try {
            await DriverService.updateRideStatus(ride.id, newStatus);
            if (newStatus === 'completed') {
                // Update driver's total rides in context
                if (driver) {
                    await setDriverData({ ...driver, total_rides: (driver.total_rides ?? 0) + 1 });
                }
                router.replace('/(tabs)/bookings');
            } else {
                setRide(prev => prev ? { ...prev, status: newStatus } : null);
            }
        } catch (e: any) {
            Alert.alert(t('common.error'), e.message ?? t('common.error'));
        } finally {
            setUpdating(false);
        }
    };

    const openMaps = (lat: number, lng: number, label: string) => {
        const url = `https://maps.google.com/?q=${lat},${lng}`;
        Linking.openURL(url).catch(() =>
            Alert.alert(t('common.error'), t('activeRide.mapsError'))
        );
    };

    const handleCancel = () => {
        Alert.alert(
            t('activeRide.cancelRide'),
            t('activeRide.cancelConfirm'),
            [
                { text: t('common.no'), style: 'cancel' },
                {
                    text: t('activeRide.cancelRide'), style: 'destructive', onPress: async () => {
                        if (!ride?.id) return;
                        await DriverService.updateRideStatus(ride.id, 'cancelled');
                        router.replace('/(tabs)/bookings');
                    }
                },
            ]
        );
    };

    if (loading || !ride) {
        return (
            <View style={[styles.container, styles.center, { paddingTop: insets.top }]}>
                <ActivityIndicator size="large" color={colors.primary} />
            </View>
        );
    }

    const step = STATUS_STEPS.find(s => s.key === ride.status);
    const stepIdx = STATUS_STEPS.findIndex(s => s.key === ride.status);

    return (
        <View style={[styles.container, { paddingTop: insets.top }]}>
            {/* Header — no back button */}
            <View style={styles.header}>
                <View>
                    <Text style={styles.headerTitle}>{t('activeRide.title')}</Text>
                    <Text style={styles.rideId}>#{ride.id.slice(-6).toUpperCase()}</Text>
                </View>
                <View style={styles.fareBadge}>
                    <Text style={styles.fareLabel}>{t('activeRide.fare')}</Text>
                    <Text style={styles.fareValue}>₹{ride.fare}</Text>
                </View>
            </View>

            {/* Progress steps */}
            <View style={styles.progressBar}>
                {STATUS_STEPS.map((s, i) => (
                    <React.Fragment key={s.key}>
                        <View style={styles.progressStep}>
                            <View style={[
                                styles.progressDot,
                                i <= stepIdx && styles.progressDotActive,
                                i < stepIdx && styles.progressDotDone,
                            ]}>
                                {i < stepIdx ? (
                                    <Feather name="check" size={10} color={colors.white} />
                                ) : (
                                    <View style={i === stepIdx ? styles.progressDotCenter : undefined} />
                                )}
                            </View>
                            <Text style={[styles.progressLabel, i <= stepIdx && styles.progressLabelActive]}>
                                {s.label.split(' ')[0]}
                            </Text>
                        </View>
                        {i < STATUS_STEPS.length - 1 && (
                            <View style={[styles.progressLine, i < stepIdx && styles.progressLineDone]} />
                        )}
                    </React.Fragment>
                ))}
            </View>

            {/* Current status card */}
            <View style={styles.statusCard}>
                <View style={styles.statusIconBox}>
                    <Feather name={(step?.icon ?? 'truck') as any} size={28} color={colors.primary} />
                </View>
                <Text style={styles.statusTitle}>{step?.label}</Text>
                <Text style={styles.distanceText}>{t('activeRide.tripDistance', { distance: ride.distance_km })}</Text>
            </View>

            {/* Route details */}
            <View style={styles.routeCard}>
                {/* Pickup */}
                <TouchableOpacity
                    style={styles.locationRow}
                    onPress={() => openMaps(
                        ride.pickup_location.latitude,
                        ride.pickup_location.longitude,
                        'Pickup'
                    )}
                    activeOpacity={0.7}
                >
                    <View style={[styles.locationDot, { backgroundColor: colors.success }]} />
                    <View style={styles.locationInfo}>
                        <Text style={styles.locationLabel}>{t('activeRide.pickup')}</Text>
                        <Text style={styles.locationAddress} numberOfLines={2}>{ride.pickup_address}</Text>
                    </View>
                    <Feather name="navigation" size={18} color={colors.primary} />
                </TouchableOpacity>

                <View style={styles.routeConnector}>
                    <View style={styles.routeConnectorLine} />
                </View>

                {/* Drop */}
                <TouchableOpacity
                    style={styles.locationRow}
                    onPress={() => openMaps(
                        ride.drop_location.latitude,
                        ride.drop_location.longitude,
                        'Drop'
                    )}
                    activeOpacity={0.7}
                >
                    <View style={[styles.locationDot, { backgroundColor: colors.error }]} />
                    <View style={styles.locationInfo}>
                        <Text style={styles.locationLabel}>{t('activeRide.dropoff')}</Text>
                        <Text style={styles.locationAddress} numberOfLines={2}>{ride.drop_address}</Text>
                    </View>
                    <Feather name="navigation" size={18} color={colors.primary} />
                </TouchableOpacity>
            </View>

            {/* Details */}
            {ride.details && (
                <View style={styles.detailsCard}>
                    <Feather name="info" size={14} color={colors.primary} />
                    <Text style={styles.detailsText}>{ride.details}</Text>
                </View>
            )}

            {/* Action button */}
            <View style={styles.actions}>
                {step && (
                    <TouchableOpacity
                        style={[styles.actionBtn, updating && styles.actionBtnLoading]}
                        onPress={handleStatusUpdate}
                        disabled={updating}
                        activeOpacity={0.85}
                    >
                        {updating ? (
                            <ActivityIndicator color={colors.white} />
                        ) : (
                            <>
                                <Feather name="check-circle" size={20} color={colors.white} />
                                <Text style={styles.actionBtnText}>{step.action}</Text>
                            </>
                        )}
                    </TouchableOpacity>
                )}

                {ride.status === 'accepted' && (
                    <TouchableOpacity style={styles.cancelBtn} onPress={handleCancel}>
                        <Text style={styles.cancelBtnText}>{t('activeRide.cancelRide')}</Text>
                    </TouchableOpacity>
                )}
            </View>

            {/* Lock note */}
            <View style={styles.lockNote}>
                <Feather name="lock" size={12} color={colors.textMuted} />
                <Text style={styles.lockText}>{t('activeRide.lockNote')}</Text>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    center: { justifyContent: 'center', alignItems: 'center' },
    header: {
        flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
        paddingHorizontal: 20, paddingVertical: 16,
        backgroundColor: colors.surface, borderBottomWidth: 1, borderBottomColor: colors.border,
    },
    headerTitle: { fontFamily: Fonts.bold, fontSize: 18, color: colors.text },
    rideId: { fontFamily: Fonts.medium, fontSize: 13, color: colors.textMuted, marginTop: 2 },
    fareBadge: { backgroundColor: colors.primaryLight, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 8, alignItems: 'center' },
    fareLabel: { fontFamily: Fonts.regular, fontSize: 11, color: colors.primary },
    fareValue: { fontFamily: Fonts.black, fontSize: 22, color: colors.primary },

    // Progress
    progressBar: {
        flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
        paddingHorizontal: 20, paddingVertical: 16,
        backgroundColor: colors.surface, marginBottom: 2,
    },
    progressStep: { alignItems: 'center', gap: 4 },
    progressDot: {
        width: 24, height: 24, borderRadius: 12, borderWidth: 2,
        borderColor: colors.border, alignItems: 'center', justifyContent: 'center',
    },
    progressDotActive: { borderColor: colors.primary, backgroundColor: colors.primaryLight },
    progressDotDone: { borderColor: colors.success, backgroundColor: colors.success },
    progressDotCenter: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.primary },
    progressLine: { flex: 1, height: 2, backgroundColor: colors.border, marginBottom: 16 },
    progressLineDone: { backgroundColor: colors.success },
    progressLabel: { fontFamily: Fonts.medium, fontSize: 10, color: colors.textMuted },
    progressLabelActive: { color: colors.primary },

    // Status card
    statusCard: {
        backgroundColor: colors.primary, marginHorizontal: 16, marginTop: 12,
        borderRadius: 20, padding: 20, alignItems: 'center', gap: 6,
        shadowColor: colors.primary, shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3, shadowRadius: 8, elevation: 5,
    },
    statusIconBox: {
        width: 52, height: 52, borderRadius: 26,
        backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center',
        marginBottom: 6,
    },
    statusTitle: { fontFamily: Fonts.bold, fontSize: 18, color: colors.white },
    distanceText: { fontFamily: Fonts.regular, fontSize: 14, color: 'rgba(255,255,255,0.75)' },

    // Route card
    routeCard: {
        backgroundColor: colors.surface, marginHorizontal: 16, marginTop: 12,
        borderRadius: 18, padding: 16, borderWidth: 1, borderColor: colors.border,
    },
    locationRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
    locationDot: { width: 12, height: 12, borderRadius: 6, flexShrink: 0 },
    locationInfo: { flex: 1 },
    locationLabel: { fontFamily: Fonts.medium, fontSize: 12, color: colors.textMuted, marginBottom: 2 },
    locationAddress: { fontFamily: Fonts.medium, fontSize: 14, color: colors.text, lineHeight: 20 },
    routeConnector: { paddingLeft: 5, paddingVertical: 4 },
    routeConnectorLine: { width: 1.5, height: 16, backgroundColor: colors.border },

    // Details
    detailsCard: {
        flexDirection: 'row', gap: 8, backgroundColor: colors.primaryLight,
        marginHorizontal: 16, marginTop: 10, borderRadius: 12, padding: 12, alignItems: 'flex-start',
    },
    detailsText: { flex: 1, fontFamily: Fonts.regular, fontSize: 13, color: colors.primary, lineHeight: 18 },

    // Actions
    actions: { marginHorizontal: 16, marginTop: 14, gap: 10 },
    actionBtn: {
        backgroundColor: colors.success, borderRadius: 16, paddingVertical: 16,
        flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10,
        shadowColor: colors.success, shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3, shadowRadius: 8, elevation: 4,
    },
    actionBtnLoading: { opacity: 0.7 },
    actionBtnText: { fontFamily: Fonts.bold, fontSize: 17, color: colors.white },
    cancelBtn: { borderWidth: 1.5, borderColor: colors.error, borderRadius: 14, paddingVertical: 13, alignItems: 'center' },
    cancelBtnText: { fontFamily: Fonts.medium, fontSize: 15, color: colors.error },

    lockNote: {
        flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
        gap: 6, marginTop: 12,
    },
    lockText: { fontFamily: Fonts.regular, fontSize: 12, color: colors.textMuted },
});
