import 'react-native-url-polyfill/auto';
import '@/config/i18n'; // Initialize i18n
import { AuthProvider, useAuth } from '@/contexts/auth-context';
import { useFonts } from 'expo-font';
import { Stack, router } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import { useEffect } from 'react';
import { SafeAreaProvider } from 'react-native-safe-area-context';

SplashScreen.preventAutoHideAsync();

function RootContent() {
    const { driver, loading } = useAuth();

    useEffect(() => {
        if (!loading) {
            if (!driver) {
                router.replace('/(auth)/login');
            } else if (!driver.is_driver || driver.rider_status === 'unsubmitted') {
                // New driver, hasn't picked vehicle + uploaded docs yet
                router.replace('/(auth)/onboarding');
            } else if (driver.rider_status === 'pending' || driver.rider_status === 'rejected') {
                // Docs submitted but not yet verified — show pending/rejected screen in onboarding
                router.replace('/(auth)/onboarding');
            } else if (driver.rider_status === 'verified') {
                // Fully verified — go to main app
                router.replace('/(tabs)/bookings');
            } else {
                // Fallback (e.g. unknown status)
                router.replace('/(auth)/onboarding');
            }
        }
    }, [driver, loading]);

    return (
        <>
            <StatusBar style="dark" />
            <Stack screenOptions={{ headerShown: false, animation: 'fade' }}>
                <Stack.Screen name="index" />
                <Stack.Screen name="(auth)" />
                <Stack.Screen name="(tabs)" />
                <Stack.Screen name="active-ride/[id]" />
            </Stack>
        </>
    );
}

export default function RootLayout() {
    const [loaded, error] = useFonts({
        'Satoshi-Regular': require('../assets/fonts/Satoshi-Regular.otf'),
        'Satoshi-Medium': require('../assets/fonts/Satoshi-Medium.otf'),
        'Satoshi-Bold': require('../assets/fonts/Satoshi-Bold.otf'),
        'Satoshi-Black': require('../assets/fonts/Satoshi-Black.otf'),
    });

    useEffect(() => {
        if (loaded || error) SplashScreen.hideAsync();
    }, [loaded, error]);

    if (!loaded && !error) return null;

    return (
        <SafeAreaProvider>
            <AuthProvider>
                <RootContent />
            </AuthProvider>
        </SafeAreaProvider>
    );
}