import { supabase } from '@/config/supabase';
import { Ride, DriverEarning } from '@/types';

export class DriverService {
    // Fetch available (pending) rides for driver's service types
    static async getAvailableRides(driverServiceTypes?: string[]): Promise<Ride[]> {
        try {
            let query = supabase
                .from('rides')
                .select('*')
                .eq('status', 'pending')
                .is('driver_id', null)
                .order('created_at', { ascending: false });

            const { data, error } = await query;
            if (error) return [];
            return (data ?? []) as Ride[];
        } catch {
            return [];
        }
    }

    // Accept a ride — atomic: only succeeds if ride is still pending+unassigned
    static async acceptRide(rideId: string, driverId: string): Promise<Ride | null> {
        // First check if driver already has an active ride
        const { data: existingRide } = await supabase
            .from('rides')
            .select('id')
            .eq('driver_id', driverId)
            .in('status', ['accepted', 'picked_up', 'on_ride'])
            .single();

        if (existingRide) {
            throw new Error('You already have an active ride');
        }

        const { data, error } = await supabase
            .from('rides')
            .update({ driver_id: driverId, status: 'accepted', updated_at: new Date().toISOString() })
            .eq('id', rideId)
            .eq('status', 'pending')
            .is('driver_id', null)
            .select()
            .single();

        if (error || !data) throw new Error('Ride no longer available');
        return data as Ride;
    }

    // Get driver's current active ride
    static async getActiveRide(driverId: string): Promise<Ride | null> {
        try {
            const { data, error } = await supabase
                .from('rides')
                .select('*')
                .eq('driver_id', driverId)
                .in('status', ['accepted', 'picked_up', 'on_ride'])
                .single();

            if (error) return null;
            return data as Ride;
        } catch {
            return null;
        }
    }

    // Update ride status
    static async updateRideStatus(
        rideId: string,
        status: 'picked_up' | 'on_ride' | 'completed' | 'cancelled'
    ): Promise<void> {
        const { error } = await supabase
            .from('rides')
            .update({ status, updated_at: new Date().toISOString() })
            .eq('id', rideId);

        if (error) throw new Error('Failed to update ride status');

        // When completing, record earnings (80% of fare goes to driver)
        if (status === 'completed') {
            const { data: ride } = await supabase
                .from('rides')
                .select('fare, driver_id')
                .eq('id', rideId)
                .single();

            if (ride?.driver_id) {
                const driverAmount = Math.round(ride.fare * 0.8 * 100) / 100;
                await supabase.from('driver_earnings').insert({
                    driver_id: ride.driver_id,
                    ride_id: rideId,
                    amount: driverAmount,
                });

                // Increment total_rides
                await supabase.rpc('increment_driver_rides', { driver_id: ride.driver_id });
            }
        }
    }

    // Subscribe to pending rides (realtime)
    static subscribeToPendingRides(callback: (rides: Ride[]) => void) {
        return supabase
            .channel('pending_rides_driver')
            .on(
                'postgres_changes',
                { event: '*', schema: 'public', table: 'rides', filter: 'status=eq.pending' },
                async () => {
                    const rides = await DriverService.getAvailableRides();
                    callback(rides);
                }
            )
            .subscribe();
    }

    // Subscribe to a specific ride's updates
    static subscribeToRide(rideId: string, callback: (ride: Ride) => void) {
        return supabase
            .channel(`driver_ride_${rideId}`)
            .on(
                'postgres_changes',
                { event: 'UPDATE', schema: 'public', table: 'rides', filter: `id=eq.${rideId}` },
                (payload) => callback(payload.new as Ride)
            )
            .subscribe();
    }

    // Get driver earnings
    static async getEarnings(driverId: string): Promise<DriverEarning[]> {
        try {
            const { data, error } = await supabase
                .from('driver_earnings')
                .select('*, ride:rides(*)')
                .eq('driver_id', driverId)
                .order('created_at', { ascending: false });

            if (error) return [];
            return (data ?? []) as DriverEarning[];
        } catch {
            return [];
        }
    }

    // Get today's earnings total
    static async getTodayEarnings(driverId: string): Promise<number> {
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        try {
            const { data } = await supabase
                .from('driver_earnings')
                .select('amount')
                .eq('driver_id', driverId)
                .gte('created_at', today.toISOString());

            return (data ?? []).reduce((sum: number, e: any) => sum + (e.amount || 0), 0);
        } catch {
            return 0;
        }
    }

    // Get ride history for driver
    static async getRideHistory(driverId: string): Promise<Ride[]> {
        try {
            const { data, error } = await supabase
                .from('rides')
                .select('*')
                .eq('driver_id', driverId)
                .in('status', ['completed', 'cancelled'])
                .order('created_at', { ascending: false });

            if (error) return [];
            return (data ?? []) as Ride[];
        } catch {
            return [];
        }
    }

    // Toggle online status
    static async setOnlineStatus(driverId: string, isOnline: boolean, lat?: number, lng?: number): Promise<void> {
        const update: any = { is_online: isOnline };
        if (lat !== undefined && lng !== undefined) {
            update.current_lat = lat;
            update.current_lng = lng;
        }
        await supabase.from('users').update(update).eq('id', driverId);
    }
}
